package com.assignment.playlist;

public class Song {
	public int songId;
	public String name;
	public String artist;
	public String album;
		
	public int getSongId() {
		return songId;
	}
	public void setSongId(int songId) {
		this.songId = songId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getArtist() {
		return artist;
	}
	public void setArtist(String artist) {
		this.artist = artist;
	}
	public String getAlbum() {
		return album;
	}
	public void setAlbum(String album) {
		this.album = album;
	}
		
	public Song(int songId, String name, String artist, String album) {
		this.songId = songId;
		this.name = name;
		this.artist = artist;
		this.album = album;
	}
	
	@Override
	public String toString() {
		return "Song [songId=" + songId + ", name=" + name + ", artist="
				+ artist + ", album=" + album + "]";
	}
	
}
