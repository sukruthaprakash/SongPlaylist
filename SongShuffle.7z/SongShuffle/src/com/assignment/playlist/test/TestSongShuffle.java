package com.assignment.playlist.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.assignment.playlist.ShuffleSong;
import com.assignment.playlist.Song;

public class TestSongShuffle {
	
	List<Song> songList = new ArrayList<Song>();
	ShuffleSong shuffleSong ;
	int size;
	  
	@Before
    public void setUp() {
		 Song song1 = new Song(123,"Rockabye", "Sean Pau", "Clean Bandit");
	      Song song2 = new Song(23,"Californication", "Red Hot Chili Peppers", "Californication");
	      Song song3 = new Song(12,"Radio Active", "Imagine Dragons", "Continued Silence");
	      Song song4 = new Song(45,"All Fall Down", "One Republic", "Dreaming Out Loud");
	      Song song5 = new Song(34,"Can't Feel My Face", "The Weeknd", "Beauty Behind the Madness");
	      Song song6 = new Song(16,"Demons", "Imagine Dragons", "Continued Silence");
	     
	      songList.add(song1);
	      songList.add(song2);
	      songList.add(song3);
	      songList.add(song4);
	      songList.add(song5);
	      songList.add(song6);
	      
		shuffleSong = new ShuffleSong(songList);
		size = songList.size();
	}
	
	@Test
	public void testPlay() {
		System.out.println("Play all song in the playlist");
		shuffleSong.setCurrentSongIndex(0);
		boolean result = shuffleSong.play();
		assertTrue(result);
	}
	
	
	@Test
	public void testPreviousWithleastVal() {
		System.out.println("Previous button on 2 song");
		shuffleSong.setCurrentSongIndex(1);
		int result = shuffleSong.previous();
		assertEquals(0, result);
	}
	
	@Test
	public void testPreviousWithMaxVal() {
		System.out.println("Previous button on last song");
		shuffleSong.setCurrentSongIndex(size-1);
		int result = shuffleSong.previous();
		assertEquals(0, result);
	}
	
	@Test
	public void testPreviousWithFirstIndex() {
		System.out.println("Previous button on 1 song");
		shuffleSong.setCurrentSongIndex(0);
		int result = shuffleSong.previous();
		assertEquals(-1, result);
	}
	
	@Test
	public void testPreviousWithMoreListSize() {
		System.out.println("Previous button for more than song list size");
		shuffleSong.setCurrentSongIndex(size);
		int result = shuffleSong.previous();
		assertEquals(-1, result);
	}
	
	
	@Test
	public void testNextWithleastVal() {
		System.out.println("Next button on 1 song");
		shuffleSong.setCurrentSongIndex(0);
		int result = shuffleSong.next();
		assertEquals(0, result);
	}
	
	@Test
	public void testNextWithMaxVal() {
		System.out.println("Next button on last second song");
		shuffleSong.setCurrentSongIndex(size-2);
		int result = shuffleSong.next();
		assertEquals(0, result);
	}
		
	@Test
	public void testNextWithMorethanListSize() {
		System.out.println("Next button for more than song list size");
		shuffleSong.setCurrentSongIndex(size);
		int result = shuffleSong.next();
		assertEquals(-1, result);
	}
	
}
