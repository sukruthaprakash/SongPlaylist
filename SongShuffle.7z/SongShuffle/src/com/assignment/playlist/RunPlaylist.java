package com.assignment.playlist;

import java.util.ArrayList;
import java.util.List;

public class RunPlaylist {

	public static void main(String[] args) {
				
		  Song song1 = new Song(123,"Rockabye", "Sean Pau", "Clean Bandit");
	      Song song2 = new Song(23,"Californication", "Red Hot Chili Peppers", "Californication");
	      Song song3 = new Song(12,"Radio Active", "Imagine Dragons", "Continued Silence");
	      Song song4 = new Song(45,"All Fall Down", "One Republic", "Dreaming Out Loud");
	      Song song5 = new Song(34,"Can't Feel My Face", "The Weeknd", "Beauty Behind the Madness");
	      Song song6 = new Song(16,"Demons", "Imagine Dragons", "Continued Silence");
	      
	      List<Song> songList = new ArrayList<Song>();
	      songList.add(song1);
	      songList.add(song2);
	      songList.add(song3);
	      songList.add(song4);
	      songList.add(song5);
	      songList.add(song6);
	     
		ShuffleSong shuffleSong = new ShuffleSong(songList);
		
		shuffleSong.play();
		
	}

}
