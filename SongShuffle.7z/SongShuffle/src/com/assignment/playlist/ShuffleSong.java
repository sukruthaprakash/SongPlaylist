package com.assignment.playlist;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;


/**
 * Java Class to generate Shuffled Song Playlist
 * @author sukrutha
 *
 */
public class ShuffleSong {
	
	  //List<Integer> shuffledSongList = new ArrayList<Integer>();
		List<Song> shuffledSongList = new ArrayList<Song>();
	     int currentSongIndex=0;
	     	    
	     
	    public int getCurrentSongIndex() {
			return currentSongIndex;
		}

		public void setCurrentSongIndex(int currentSongIndex) {
			this.currentSongIndex = currentSongIndex;
		}

		
		public ShuffleSong(List<Song> list){
	    	shuffleSongList(list);
	    	System.out.println("------------Shuffled Song List------------");
	    	System.out.println("------------start------------");
	    	for(int i = getCurrentSongIndex();i < shuffledSongList.size();i++){
				System.out.print("Song ID: "+shuffledSongList.get(i).getSongId());
				System.out.println(" Song Name: "+shuffledSongList.get(i).getName());
				setCurrentSongIndex(i);
			}
	    	System.out.println("------------end--------------");
	 	}
	    
	   
	    /**
	     * Method to shuffle song randomly
	     * @param songList
	     * @return shuffledSongList
	     */
	    public List<Song> shuffleSongList(List<Song> songList){
	    	Map<Integer,Integer> map = new HashMap<>();
	    	int size = songList.size();
	        for(int i = 0;i<size;i++) {
	            int rnd = new Random().nextInt(size);
	            
	           if (map.get(songList.get(rnd).getSongId()) == null) {
	        	   Integer num = songList.get(rnd).getSongId();
	        	    map.put(num, 1);
	                shuffledSongList.add(songList.get(rnd));
	               
	            } else {
	                map.put(songList.get(rnd).getSongId(), map.get(songList.get(rnd).getSongId())+1);
	                --i;
	           }
	        }
	        return shuffledSongList;
	    }
	    
	     /**Method to get song index by  song ID
	     * @param songID
	     * @return indexID
	     */
	    public int getIndex(int songID){
	        for(int i = 0; i< shuffledSongList.size(); i++){
	        	if(shuffledSongList.get(i).getSongId() == songID){
	        		return i;
	        	}
	        }
	        return -1;
	    }
	    
	    /**
	     * Method to play previous song based on current index
	     * @return 
	     */
	    public  int previous(){
	    	if(shuffledSongList.isEmpty() || getCurrentSongIndex() <= 0 || shuffledSongList.size() <= getCurrentSongIndex()){
	    		System.out.println("Invalid input");
	            return -1;
	        }
	    	else{
	    		setCurrentSongIndex(getCurrentSongIndex() -1);
	    		play();
	    		return 0;
	    	}
	    }
	   
	    /**
	     * Method to play next song based on current index
	     * @return 
	     */
	    public int next(){
	    	if(shuffledSongList.isEmpty() || getCurrentSongIndex() >= shuffledSongList.size()-1  || getCurrentSongIndex() < 0){
	    		System.out.println("Invalid input");
	            return -1;
	        }
	    	else{
	    		setCurrentSongIndex(getCurrentSongIndex()+1);
	    		play();
	    		return 0;
	    	}
	    }
	    	    
	    /**
	     * Method to play song based on current index
	     * @return
	     */
	    public  boolean play(){
	    	if(!shuffledSongList.isEmpty()){
	    		System.out.println("Play list");
	    		System.out.println("------------start------------");
		    	for(int i = getCurrentSongIndex();i < shuffledSongList.size();i++){
					System.out.print("Song ID: "+shuffledSongList.get(i).getSongId());
					System.out.println(" Song Name: "+shuffledSongList.get(i).getName());
					setCurrentSongIndex(i);
				}
		    	System.out.println("------------end--------------");
		    	return true;
	    	}
	    	else{
	    		return false;
	    	}
			
	    }

}
